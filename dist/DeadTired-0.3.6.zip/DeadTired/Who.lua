-- Dead Tired: Who, the walk module. Who in the guild runs Dead Tired.
--   HELLO { v, rn, login }: sent once after login (and after a /reload), and in answer to a login
--     HELLO or a WHO, at most once per 10 s, after a short random wait so answers don't pile up.
--     Shares your key (name and realm), your realm's display name and DT's version, only while
--     who.hello is on.
--   WHO { v, rn }: /dt who asks everyone once; again only after 30 s. /dt who also opens the list.
-- The list (searchable) shows each key with DT.display, its version and "this session" or "seen
-- before" (kept in DeadTiredDB.who.seen). Your own key is never listed as someone else. Only
-- guildies who run Dead Tired can show, and the window says so. The bar object reads
-- "DT: <n> online", n being the guildies heard from this session.
-- Port 1: R-P6, your own entry is listed first, marked "(you)", exactly once (still never as
-- someone else); R-P5, names without realm (the realm in the row's tooltip, or shown only to tell
-- two same-named apart); rows as tall as their wrapped name; an empty-state line. Other modules add
-- fields to HELLO with DT.helloField(name, fn) (Alts: the main; Prep: the list's version) and read
-- them with their own DT.on("HELLO") handler.
local ADDON, ns = ...
local DT = ns.DT
local try, clean = DT.try, DT.clean

local HELLO_GAP, ASK_GAP, LOGIN_WAIT = 10, 30, 5
local NOTE = "Only guildies running Dead Tired show here."
local EMPTY = "Just you so far. The rest are still in their coffins."
local YOU = " (you)"
local ICON = [[Interface\Icons\Spell_Shadow_AnimateDead]]

local session = {}          -- [key] = { v, rn, t }
local lastHello, lastAsk = nil, nil
local helloDue, greeted = false, false
local vp, list, model = nil, nil, nil

local function seen()
  local db = DT.db()
  if type(db.who) ~= "table" then db.who = {} end
  if type(db.who.seen) ~= "table" then db.who.seen = {} end
  return db.who.seen
end

local function isMe(key)
  local me = DT.myKey()
  return me ~= nil and DT.sameKey(key, me)
end

function DT.whoRows()
  local rows, done, keys = {}, {}, {}
  local function add(key, e, here)
    if done[key] then return end
    done[key] = true
    if isMe(key) then return end                                           -- guard: self never listed
    keys[#keys + 1] = key
    rows[#rows + 1] = { key = key, v = DT.safe(e.v or "?", 16), when = here and "this session" or "seen before" }
  end
  for key, e in pairs(session) do add(key, e, true) end
  for key, e in pairs(seen()) do add(key, e, false) end
  local me = DT.myKey()
  if me then keys[#keys + 1] = me end
  local name = DT.namer(keys)
  for _, r in ipairs(rows) do
    r.name = name(r.key)
    r.search = r.name .. " " .. r.key
  end
  table.sort(rows, function(a, b)
    if (a.when == "this session") ~= (b.when == "this session") then return a.when == "this session" end
    return a.name:lower() < b.name:lower()
  end)
  if me then                                                               -- R-P6: you first, once
    local n = name(me)
    table.insert(rows, 1, { key = me, you = true, name = n .. YOU, v = DT.safe(DT.VERSION, 16), when = "you",
      search = n .. " you " .. me })
  end
  return rows
end

-- A row's tooltip: the full name and the realm (R-P5).
local function tip(row, tt)
  local _, n = DT.splitKey(row.key)
  tt:AddLine(DT.safe(n or row.key, 48) .. (row.you and YOU or ""))
  tt:AddLine(DT.realmLabel(row.key), 1, 1, 1)
  tt:AddLine("Dead Tired " .. row.v, 0.7, 0.7, 0.7)
end

function DT.whoCount()
  local n = 0
  for key in pairs(session) do if not isMe(key) then n = n + 1 end end
  return n
end

local function redraw()
  DT.update("who", "text", "DT: " .. DT.whoCount() .. " online")
  if model then model:set(DT.whoRows()); list:refresh() end
end

local function record(key, d)
  if type(key) ~= "string" or isMe(key) then return end
  local v = type(d.v) == "string" and DT.safe(d.v, 16) or "?"
  local rn = type(d.rn) == "string" and d.rn:match("%S") and DT.safe(d.rn, 40) or nil   -- guard: empty rn not stored
  local r = DT.splitKey(key)
  if r and rn then DT.realmNames[r] = rn end
  session[key] = { v = v, rn = rn, t = DT.now() }
  seen()[key] = { v = v, rn = rn, last = DT.stamp() }
  redraw()
end

-- Fields other modules add to every HELLO: name -> fn() returning a plain value (or nil).
local extra = {}
function DT.helloField(name, fn) extra[name] = fn end

-- R-F7-5 (0.3.4): the realm's name only when the game gives one ("" since build 71037).
local function realmName()
  local rn = clean((try(GetRealmName)))
  if type(rn) ~= "string" or not rn:match("%S") then return nil end      -- guard: empty rn not sent
  return rn
end

local function hello(login)
  if not DT.get("who", "hello") then return false end
  local t = DT.now()
  if lastHello and t - lastHello < HELLO_GAP then return false end         -- guard: hello rate limit
  lastHello = t
  local d = { v = DT.VERSION, rn = realmName(), login = login or nil }
  for k, fn in pairs(extra) do
    local ok, v = pcall(fn)
    if ok and v ~= nil and d[k] == nil then d[k] = v end
  end
  return DT.send("HELLO", d)
end
-- A fresh HELLO now (Alts: after /dt main), past the 10 s limit only once a gap has passed.
function DT.sayHello() lastHello = nil; return hello(false) end

local function answer()
  DT.after(1 + math.random() * 2, function() if DT.enabled("who") then hello(false) end end)
end

DT.on("HELLO", function(from, d)
  if not DT.enabled("who") then return end
  record(from, d)
  if d.login then answer() end
end)
DT.on("WHO", function(from, d)
  if not DT.enabled("who") then return end
  record(from, d)
  answer()
end)

-- /dt who: ask once (rate-limited) and open the list.
local function ask()
  if not DT.enabled("who") then return DT.out("who.enabled = off") end
  local t = DT.now()
  if not lastAsk or t - lastAsk >= ASK_GAP then                            -- guard: ask rate limit
    lastAsk = t
    DT.send("WHO", { v = DT.VERSION, rn = realmName() })
  end
  DT.openWho()
end

-- Fix round 4: the note is the viewport's footer; the version and "when" columns are as wide as
-- their widest value, the name takes the rest. The tooltip keeps its realm line (R-P5, R-F4-10).
local function build()
  if vp then return end
  model = DT.listModel()
  vp = DT.viewport({ id = "who", title = "Who runs Dead Tired", search = true, width = 380, height = 400,
    footer = NOTE, onSearch = function(text) model:filter(text); list.offset = 0; list:refresh() end })
  list = DT.list(vp.body, model, { count = 16, tip = tip, empty = function(m)
      if (DT.trim(m.query) or "") ~= "" or #m.rows > 1 then return nil end
      return EMPTY
    end, columns = {
    { key = "name", flex = true }, { key = "v", fixed = true, colour = "muted" }, { key = "when", fixed = true, colour = "muted" } } })
end

function DT.openWho()
  if not DT.isMember() then return end
  build()
  model:set(DT.whoRows())
  list:refresh()
  vp:Show()
  DT.whoListShown = list
end

local function loginHello()
  if helloDue or not greeted or not DT.isMember() or not DT.enabled("who") then return end
  helloDue = true
  DT.after(LOGIN_WAIT, function() hello(true) end)
end

DT.module({
  id = "who",
  title = "Who",
  optional = true,
  switchDesc = "Who in the guild runs Dead Tired. Off, Dead Tired neither says hello nor answers.",
  settings = {
    { key = "hello", type = "bool", default = true, label = "Say hello",
      desc = "When you log in, and when a guildie asks, tells guildies running Dead Tired that you run it too. Shares your name, realm and Dead Tired version." },
  },
  verbs = { { verb = "who", usage = "who", fn = ask } },
  ldb = { type = "data source", text = "DT: 0 online", icon = ICON,
    OnClick = function(_, which) if which == "RightButton" then DT.openSettings("who") else DT.openWho() end end,
    OnTooltipShow = function(tt) tt:AddLine("Who runs Dead Tired"); tt:AddLine(NOTE, 1, 1, 1) end },
  onEnable = function() loginHello() end,
  fit = function() build(); model:set(DT.whoRows()); list:refresh() end,
})

-- After the welcome (Guild.lua: once per login, inside the guild), the login hello.
DT.listen("greeted", function() greeted = true; loginHello() end)

DT.keySource(function() return session end)
DT.keySource(function() return seen() end)

DT._who = { NOTE = NOTE, EMPTY = EMPTY, list = function() return list end, session = function() return session end, record = record,
  reset = function() lastHello, lastAsk = nil, nil end }
